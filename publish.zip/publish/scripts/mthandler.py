from getpass import getpass
import json
import requests
import deepl


class Blank():
    def __init__(self) -> None:
        pass

    def prepare(self, username: str, password: str, src_lang: str, tgt_lang: str, **kwargs) -> bool:
        pass

    def set_langs(self, src_lang: str, tgt_lang: str):
        pass

    def get_mt(self, st: str) -> str:
        pass


class ATMAN():
    def __init__(self) -> None:
        self.BASE = "https://fanyi.atman360.com"
        self.EPS = {
            "login": "/api/user/login/",
            "profile": "/api/user/profile/",
            "split": "/api/trans/sentence/tokenizer/",
            "mt-text": "/api/trans/batch/",
            "mt-file": "/api/trans/document/",
            "mt-file-prog": "/api/trans/document-progress/",
            "mt-file-dl": "/api/trans/document-download/",
        }
        self.DOMAINS = [
            "medical",
            "medical-pv",
            "medical-device",
            "medical-cmc",
            "medical-clinical",
            "medical-nonclinical",
            "medical-regulation",
        ]
        self.domain = "medical"
        self.authhead = ""
        self.team_id = 0
        self.src_lang = "en"
        self.tgt_lang = "zh"

    def prepare(self, username, password, src_lang, tgt_lang, domain="medical") -> bool:
        isMtOk = False
        isLoggedIn = self.login(username, password)
        if isLoggedIn:
            self.set_langs(src_lang, tgt_lang)
            self.set_domain(domain)
            isMtOk = self.get_team_id()
        return isMtOk

    def login(self, username, password) -> bool:
        auth = {
            "username": username,
            "password": password,
        }

        res = requests.post(
            self.BASE + self.EPS["login"],
            json.dumps(auth),
            headers={"Content-Type": "application/json"},
        )
        if res.status_code == 200:
            atkn = res.json()["data"]["authtoken"]
            self.authhead = f"Token {atkn}"
            return True
        else:
            return False

    def get_team_id(self) -> bool:
        res = requests.get(
            self.BASE + self.EPS["profile"],
            headers={"Authorization": self.authhead}
        )
        if res.status_code == 200:
            data = res.json()
            self.team_id = int(data["data"]["member"][0]["team_id"])
            return True
        else:
            return False

    def set_langs(self, src_lang: str, tgt_lang: str):
        chinese = ["zh", "zh-cn", "cn", "chinese"]
        english = ["en", "en-us", "english"]
        if src_lang.lower() in chinese:
            self.src_lang = "zh"
            self.tgt_lang = "en"
        elif src_lang.lower() in english:
            self.src_lang = "en"
            self.tgt_lang = "zh"

    def set_domain(self, domain):
        if self.src_lang != "en":
            return
        elif domain in self.DOMAINS:
            self.domain = domain

    def get_mt(self, src: str) -> str:
        if self.authhead == "" or self.team_id == 0:
            print("Please Login")
        else:
            body = {
                "lines": [
                    {
                        "id": 0,
                        "text": src
                    }
                ],
                "domain": self.domain,
                "source": self.src_lang,
                "target": self.tgt_lang,
                "team_id": self.team_id,
                "translation_number": 1,
            }
            res = requests.post(
                self.BASE + self.EPS["mt-text"],
                json.dumps(body),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": self.authhead
                }
            )
            data = res.json()
            return data["data"][0]["text"]


class DeepL():
    def __init__(self) -> None:
        self.translator = None
        self.src_lang = "JA"
        self.tgt_lang = "ZH"

    def prepare(self, username: str, password: str, src_lang: str, tgt_lang: str) -> bool:
        self.translator = deepl.Translator(password)
        self.set_langs(src_lang, tgt_lang)
        return True

    def set_langs(self, src_lang: str, tgt_lang: str):
        self.src_lang = src_lang.upper()
        self.tgt_lang = tgt_lang.upper()

    def get_mt(self, st: str) -> str:
        res = self.translator.translate_text(
            st, source_lang=self.src_lang, target_lang=self.tgt_lang)
        return res.text
